<?php
header("juhu: kinners");
?>
<?php
echo json_encode(getallheaders());
?>
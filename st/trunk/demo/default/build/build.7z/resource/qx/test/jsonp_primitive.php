<?php
  echo $_GET['callback'] . '({"string": "String", "number": 12, "boolean": true, "null": null});'
?>